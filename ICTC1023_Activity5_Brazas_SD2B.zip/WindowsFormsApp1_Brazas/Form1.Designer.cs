﻿
namespace WindowsFormsApp1_Brazas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_getMessage = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_getMessage
            // 
            this.btn_getMessage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_getMessage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_getMessage.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_getMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_getMessage.Location = new System.Drawing.Point(75, 56);
            this.btn_getMessage.Name = "btn_getMessage";
            this.btn_getMessage.Size = new System.Drawing.Size(119, 51);
            this.btn_getMessage.TabIndex = 0;
            this.btn_getMessage.Text = "Get Message";
            this.btn_getMessage.UseVisualStyleBackColor = false;
            this.btn_getMessage.Click += new System.EventHandler(this.btn_getMessage_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(266, 172);
            this.Controls.Add(this.btn_getMessage);
            this.Name = "Form1";
            this.Text = "Message";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_getMessage;
    }
}

