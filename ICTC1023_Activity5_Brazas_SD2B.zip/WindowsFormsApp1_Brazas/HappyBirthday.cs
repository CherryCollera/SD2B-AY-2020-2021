﻿namespace WindowsFormsApp1_Brazas
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Birthday " + firstname;
        }
    }
}
