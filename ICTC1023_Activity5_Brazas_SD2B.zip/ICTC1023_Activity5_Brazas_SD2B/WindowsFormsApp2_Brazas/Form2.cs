﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp2_Brazas
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void txtBox_Firstname_Click(object sender, EventArgs e)
        {
            textBox_getFirstname.Text = " ";
        }

        private void txtBox_Lastname_Click(object sender, EventArgs e)
        {
            txtBox_getLastname.Text = " ";
        }

        private void btn_getMessage_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Happy Birthday " + textBox_getFirstname.Text + " " + txtBox_getLastname.Text + " !");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            this.Hide();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            Form3 F3 = new Form3();
            F3.textBox_getFirstname.Text = textBox_getFirstname.Text;
            F3.txtBox_getLastname.Text = txtBox_getLastname.Text;
            F3.Show();
            this.Hide();
        }

        private void F2_ClosingBtn(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            MessageBox.Show("Warning! The program is still running!");
        }

        private void textBox_getFirstname_TextChanged(object sender, EventArgs e)
        {
            textBox_getFirstname.Font = new Font(textBox_getFirstname.Font, FontStyle.Regular);
        }

        private void txtBox_getLastname_TextChanged(object sender, EventArgs e)
        {
            txtBox_getLastname.Font = new Font(txtBox_getLastname.Font, FontStyle.Regular);
        }
    }
}
