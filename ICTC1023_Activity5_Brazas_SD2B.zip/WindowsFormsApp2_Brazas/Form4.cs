﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp2_Brazas
{
    public partial class Form4 : Form
    {
        double num1, num2;
        public Form4()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form3 F3 = new Form3();
            F3.Show();
            this.Hide();
        }

        private void btn_getDiff_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(textBox_getNum1.Text);
            num2 = Convert.ToDouble(textBox_getNum2.Text);
            textBox_Answer.Text = (num1 - num2).ToString();
        }

        private void btn_getProduct_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(textBox_getNum1.Text);
            num2 = Convert.ToDouble(textBox_getNum2.Text);
            textBox_Answer.Text = (num1 * num2).ToString();
        }

        private void btn_getQuotient_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(textBox_getNum1.Text);
            num2 = Convert.ToDouble(textBox_getNum2.Text);
            textBox_Answer.Text = (num1 / num2).ToString();
        }

        private void btn_getRemainder_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(textBox_getNum1.Text);
            num2 = Convert.ToDouble(textBox_getNum2.Text);
            textBox_Answer.Text = (num1 % num2).ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox_Answer.Text = null;
            textBox_getNum1.Text = null;
            textBox_getNum2.Text = null;
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(textBox_getNum1.Text);
            num2 = Convert.ToDouble(textBox_getNum2.Text);
            textBox_Answer.Text = (num1 + num2).ToString();
        }

        private void F4_ClosingBtn(object sender, FormClosingEventArgs e)
        {
            string message = "Are you sure about closing the program?";
            string title = "Close Program";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.Yes)
            {
                MessageBox.Show("Program Terminated...");
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            string message = "Are you sure about closing the program?";
            string title = "Close Program";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.Yes)
            {
                MessageBox.Show("Program Terminated...");
                this.Close();
            }
        }
    }
}
