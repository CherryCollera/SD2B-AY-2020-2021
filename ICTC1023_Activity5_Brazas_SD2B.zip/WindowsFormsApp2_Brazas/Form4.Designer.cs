﻿
namespace WindowsFormsApp2_Brazas
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_getNum1 = new System.Windows.Forms.TextBox();
            this.textBox_getNum2 = new System.Windows.Forms.TextBox();
            this.btn_getDiff = new System.Windows.Forms.Button();
            this.btn_getProduct = new System.Windows.Forms.Button();
            this.btn_getQuotient = new System.Windows.Forms.Button();
            this.btn_getRemainder = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.textBox_Answer = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnSum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(72, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "1ST Number   : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(72, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "2ND Number : ";
            // 
            // textBox_getNum1
            // 
            this.textBox_getNum1.Location = new System.Drawing.Point(190, 33);
            this.textBox_getNum1.Name = "textBox_getNum1";
            this.textBox_getNum1.Size = new System.Drawing.Size(108, 23);
            this.textBox_getNum1.TabIndex = 2;
            // 
            // textBox_getNum2
            // 
            this.textBox_getNum2.Location = new System.Drawing.Point(190, 66);
            this.textBox_getNum2.Name = "textBox_getNum2";
            this.textBox_getNum2.Size = new System.Drawing.Size(108, 23);
            this.textBox_getNum2.TabIndex = 3;
            // 
            // btn_getDiff
            // 
            this.btn_getDiff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_getDiff.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_getDiff.Location = new System.Drawing.Point(150, 116);
            this.btn_getDiff.Name = "btn_getDiff";
            this.btn_getDiff.Size = new System.Drawing.Size(79, 40);
            this.btn_getDiff.TabIndex = 5;
            this.btn_getDiff.Text = "-";
            this.btn_getDiff.UseVisualStyleBackColor = false;
            this.btn_getDiff.Click += new System.EventHandler(this.btn_getDiff_Click);
            // 
            // btn_getProduct
            // 
            this.btn_getProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_getProduct.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_getProduct.Location = new System.Drawing.Point(244, 116);
            this.btn_getProduct.Name = "btn_getProduct";
            this.btn_getProduct.Size = new System.Drawing.Size(79, 40);
            this.btn_getProduct.TabIndex = 6;
            this.btn_getProduct.Text = "*";
            this.btn_getProduct.UseVisualStyleBackColor = false;
            this.btn_getProduct.Click += new System.EventHandler(this.btn_getProduct_Click);
            // 
            // btn_getQuotient
            // 
            this.btn_getQuotient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_getQuotient.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_getQuotient.Location = new System.Drawing.Point(101, 172);
            this.btn_getQuotient.Name = "btn_getQuotient";
            this.btn_getQuotient.Size = new System.Drawing.Size(79, 40);
            this.btn_getQuotient.TabIndex = 7;
            this.btn_getQuotient.Text = "/";
            this.btn_getQuotient.UseVisualStyleBackColor = false;
            this.btn_getQuotient.Click += new System.EventHandler(this.btn_getQuotient_Click);
            // 
            // btn_getRemainder
            // 
            this.btn_getRemainder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_getRemainder.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_getRemainder.Location = new System.Drawing.Point(201, 172);
            this.btn_getRemainder.Name = "btn_getRemainder";
            this.btn_getRemainder.Size = new System.Drawing.Size(79, 40);
            this.btn_getRemainder.TabIndex = 8;
            this.btn_getRemainder.Text = "%";
            this.btn_getRemainder.UseVisualStyleBackColor = false;
            this.btn_getRemainder.Click += new System.EventHandler(this.btn_getRemainder_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBack.Location = new System.Drawing.Point(54, 312);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(68, 25);
            this.btnBack.TabIndex = 9;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // textBox_Answer
            // 
            this.textBox_Answer.Enabled = false;
            this.textBox_Answer.Location = new System.Drawing.Point(181, 243);
            this.textBox_Answer.Name = "textBox_Answer";
            this.textBox_Answer.Size = new System.Drawing.Size(108, 23);
            this.textBox_Answer.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(92, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Answer   : ";
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnClose.Location = new System.Drawing.Point(255, 312);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(68, 25);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(156, 312);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(68, 25);
            this.button1.TabIndex = 14;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSum
            // 
            this.btnSum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSum.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSum.Location = new System.Drawing.Point(54, 116);
            this.btnSum.Name = "btnSum";
            this.btnSum.Size = new System.Drawing.Size(79, 40);
            this.btnSum.TabIndex = 15;
            this.btnSum.Text = "+";
            this.btnSum.UseVisualStyleBackColor = false;
            this.btnSum.Click += new System.EventHandler(this.btnSum_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(363, 372);
            this.Controls.Add(this.btnSum);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.textBox_Answer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btn_getRemainder);
            this.Controls.Add(this.btn_getQuotient);
            this.Controls.Add(this.btn_getProduct);
            this.Controls.Add(this.btn_getDiff);
            this.Controls.Add(this.textBox_getNum2);
            this.Controls.Add(this.textBox_getNum1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.F4_ClosingBtn);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_getNum1;
        private System.Windows.Forms.TextBox textBox_getNum2;
        private System.Windows.Forms.Button btn_getDiff;
        private System.Windows.Forms.Button btn_getProduct;
        private System.Windows.Forms.Button btn_getQuotient;
        private System.Windows.Forms.Button btn_getRemainder;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox textBox_Answer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSum;
    }
}