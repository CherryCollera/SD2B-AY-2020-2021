﻿
namespace WindowsFormsApp2_Brazas
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBox_getLastname = new System.Windows.Forms.TextBox();
            this.textBox_getFirstname = new System.Windows.Forms.TextBox();
            this.lbl_Lastname = new System.Windows.Forms.Label();
            this.lbl_Firstname = new System.Windows.Forms.Label();
            this.lbl_MyProfile = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btn_getProfile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtBox_getLastname
            // 
            this.txtBox_getLastname.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.txtBox_getLastname.Location = new System.Drawing.Point(184, 132);
            this.txtBox_getLastname.Name = "txtBox_getLastname";
            this.txtBox_getLastname.Size = new System.Drawing.Size(233, 27);
            this.txtBox_getLastname.TabIndex = 7;
            this.txtBox_getLastname.Text = "Enter Lastname";
            this.txtBox_getLastname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBox_getLastname.Click += new System.EventHandler(this.txtBox_getLastname_Click);
            this.txtBox_getLastname.TextChanged += new System.EventHandler(this.txtBox_getLastname_TextChanged);
            // 
            // textBox_getFirstname
            // 
            this.textBox_getFirstname.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.textBox_getFirstname.Location = new System.Drawing.Point(184, 93);
            this.textBox_getFirstname.Name = "textBox_getFirstname";
            this.textBox_getFirstname.Size = new System.Drawing.Size(233, 27);
            this.textBox_getFirstname.TabIndex = 6;
            this.textBox_getFirstname.Text = "Enter Firstname";
            this.textBox_getFirstname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_getFirstname.Click += new System.EventHandler(this.txtBox_getFirstname_Click);
            this.textBox_getFirstname.TextChanged += new System.EventHandler(this.textBox_getFirstname_TextChanged);
            // 
            // lbl_Lastname
            // 
            this.lbl_Lastname.AutoSize = true;
            this.lbl_Lastname.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Lastname.Location = new System.Drawing.Point(65, 135);
            this.lbl_Lastname.Name = "lbl_Lastname";
            this.lbl_Lastname.Size = new System.Drawing.Size(85, 20);
            this.lbl_Lastname.TabIndex = 5;
            this.lbl_Lastname.Text = "Lastname :";
            // 
            // lbl_Firstname
            // 
            this.lbl_Firstname.AutoSize = true;
            this.lbl_Firstname.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Firstname.Location = new System.Drawing.Point(65, 100);
            this.lbl_Firstname.Name = "lbl_Firstname";
            this.lbl_Firstname.Size = new System.Drawing.Size(87, 20);
            this.lbl_Firstname.TabIndex = 4;
            this.lbl_Firstname.Text = "Firstname :";
            // 
            // lbl_MyProfile
            // 
            this.lbl_MyProfile.AutoSize = true;
            this.lbl_MyProfile.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_MyProfile.Location = new System.Drawing.Point(147, 42);
            this.lbl_MyProfile.Name = "lbl_MyProfile";
            this.lbl_MyProfile.Size = new System.Drawing.Size(201, 30);
            this.lbl_MyProfile.TabIndex = 8;
            this.lbl_MyProfile.Text = "M Y    P R O F I L E ";
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnNext.Location = new System.Drawing.Point(332, 200);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(85, 42);
            this.btnNext.TabIndex = 10;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBack.Location = new System.Drawing.Point(217, 200);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(85, 42);
            this.btnBack.TabIndex = 9;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btn_getProfile
            // 
            this.btn_getProfile.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_getProfile.Location = new System.Drawing.Point(67, 200);
            this.btn_getProfile.Name = "btn_getProfile";
            this.btn_getProfile.Size = new System.Drawing.Size(121, 42);
            this.btn_getProfile.TabIndex = 11;
            this.btn_getProfile.Text = "Get My Profile";
            this.btn_getProfile.UseVisualStyleBackColor = true;
            this.btn_getProfile.Click += new System.EventHandler(this.btn_getProfile_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(496, 310);
            this.Controls.Add(this.btn_getProfile);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lbl_MyProfile);
            this.Controls.Add(this.txtBox_getLastname);
            this.Controls.Add(this.textBox_getFirstname);
            this.Controls.Add(this.lbl_Lastname);
            this.Controls.Add(this.lbl_Firstname);
            this.Name = "Form3";
            this.Text = "Form3";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.F3_ClosingBtn);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txtBox_getLastname;
        public System.Windows.Forms.TextBox textBox_getFirstname;
        private System.Windows.Forms.Label lbl_Lastname;
        private System.Windows.Forms.Label lbl_Firstname;
        private System.Windows.Forms.Label lbl_MyProfile;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btn_getProfile;
    }
}