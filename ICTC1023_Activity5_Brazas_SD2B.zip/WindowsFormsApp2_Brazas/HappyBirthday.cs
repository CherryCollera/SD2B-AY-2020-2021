﻿namespace WindowsFormsApp2_Brazas
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Birthday " + firstname;
        }
    }
}
