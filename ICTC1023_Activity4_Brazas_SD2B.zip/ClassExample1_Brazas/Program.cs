﻿using System;

namespace ClassExample1_Brazas
{
    class Program
    {
        static void Main(string[] args)
        {
            Accept a = new Accept();
            a.AcceptDetails();
            Print p = new Print();
            p.PrintDetails();
            MyProfile mp = new MyProfile();
            mp.DisplayProfile();
            Console.ReadLine();
        }
    }
}
