﻿class Print
{
    public void PrintDetails()
    {
        System.Console.Write("\n\tHello " + Accept.firstname + " " + Accept.lastname + "!!!\n\tYou have created classes in OOP.");
    }
}
