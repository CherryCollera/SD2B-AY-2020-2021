﻿class Accept
{
    public static string firstname, lastname;
    public void AcceptDetails()
    {
        System.Console.Write("Enter your Firstname:\t");
        firstname = System.Console.ReadLine();
        System.Console.Write("            Lastname:\t");
        lastname = System.Console.ReadLine();
    }
}
