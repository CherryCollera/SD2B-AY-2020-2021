﻿class MyProfile
{
    public void DisplayProfile()
    {
        System.Console.WriteLine("\n\n\n\t\tP   R   O   F   I   L   E");
        System.Console.WriteLine("\n\n\t\tName:\t\tWelmar Alex Brazas");
        System.Console.WriteLine("\n\t\tBirthdate:\tMay 20, 2000");
        System.Console.WriteLine("\n\t\tCourse:\t\tBS in Computer Science Major in Software Development");
        System.Console.WriteLine("\n\t\tYear:\t\tSecond Year");
        System.Console.WriteLine("\n\t\tSection:\tSD2A");
        System.Console.ReadLine();
    }
}