﻿class Input
{
    public void InputData()
    {
        System.Console.Write("Enter 1ST number: ");
        DeclareVar.num1 = System.Convert.ToInt32(System.Console.ReadLine());
        System.Console.Write("Enter 2ND number: ");
        DeclareVar.num2 = System.Convert.ToInt32(System.Console.ReadLine());
    }
}
