﻿class Remainder
{
    public void GetRemainder()
    {
        DeclareVar.remainder = DeclareVar.num1 % DeclareVar.num2;
        System.Console.WriteLine("\nThe remainder is {0}.", DeclareVar.remainder);
    }
}