﻿class Quotient
{
    public void ComputeQuotient()
    {
        DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
        System.Console.WriteLine("\nThe quotient of the two numbers is {0}.", DeclareVar.quotient);
    }
}