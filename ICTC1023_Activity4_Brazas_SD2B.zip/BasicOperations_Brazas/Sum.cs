﻿class Sum
{
    public void ComputeSum()
    {
        DeclareVar.sum = (DeclareVar.num1 + DeclareVar.num2);
        System.Console.WriteLine("The sum of the two numbers is {0}.", DeclareVar.sum);
    }
}
