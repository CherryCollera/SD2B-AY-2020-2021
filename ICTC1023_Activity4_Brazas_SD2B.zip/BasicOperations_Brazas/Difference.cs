﻿class Difference
{
    public void ComputeDifference()
    {
        DeclareVar.diff = DeclareVar.num1 - DeclareVar.num2;
        System.Console.WriteLine("\nThe difference of the two numbers is {0}.", DeclareVar.diff);
    }
}
