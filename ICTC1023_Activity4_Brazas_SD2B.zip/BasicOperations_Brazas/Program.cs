﻿using System;

namespace BasicOperations_Brazas
{
    class Program
    {
        static void Main(string[] args)
        {
            Input input = new Input();
            input.InputData();

            Console.WriteLine("\n\nR   E   S   U   L   T \n\n");

            Sum sum = new Sum();
            sum.ComputeSum();

            Difference diff = new Difference();
            diff.ComputeDifference();

            Product product = new Product();
            product.ComputeProduct();
            
            Quotient quotient = new Quotient();
            quotient.ComputeQuotient();
            
            Remainder remainder = new Remainder();
            remainder.GetRemainder();

            Console.ReadKey();
        }
    }
}
