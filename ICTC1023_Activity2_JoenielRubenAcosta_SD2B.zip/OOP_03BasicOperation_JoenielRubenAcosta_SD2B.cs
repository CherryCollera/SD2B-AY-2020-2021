﻿using System;

namespace Acosta_JoenielRuben_M
{
    public class BasicOperation
    {
        public static void Main(string[] args)
        {


            Console.Write("Entet First Number: ");
            int fnum = Convert.ToInt32(Console.ReadLine());
            Console.Write("Entet Second Number: ");
            int snum = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();


            Console.WriteLine("Addition: {0}", fnum + snum);
            Console.WriteLine("Subtraction: {0}", fnum - snum);
            Console.WriteLine("Multiplication: {0}", fnum * snum);
            Console.WriteLine("Division: {0}", fnum / snum);
            Console.WriteLine("Modulo: {0}", fnum % snum);
        }
    }
}