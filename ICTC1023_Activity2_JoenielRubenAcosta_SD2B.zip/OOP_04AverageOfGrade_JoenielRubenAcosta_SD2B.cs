﻿using System;

namespace Acosta_JoenielRuben_M
{
    public class AverageOfGrade
    {
        public static void Main(string[] args)
        {
            Console.Write("Enter First Grade: ");
            double firstgrd = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Grade: ");
            double secondgrd = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Third Grade: ");
            double thirdgrd = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Fourth Grade: ");
            double fourthgrd = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Fifth Grade: ");
            double fifthgrd = Convert.ToDouble(Console.ReadLine());

            double result = firstgrd + secondgrd + thirdgrd + fourthgrd + fifthgrd;
            double finalresult = result / 5;

            Console.Write("Total Grade: {0:N3}", finalresult);
        }
    }
}

