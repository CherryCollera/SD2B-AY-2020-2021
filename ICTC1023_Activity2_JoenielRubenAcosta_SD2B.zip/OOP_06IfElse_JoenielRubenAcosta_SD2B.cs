﻿using System;

namespace Acosta_JoenielRuben_M
{
    public class IfElse
    {
        public static void Main(string[] args)
        {

            int exit = 0;

            while (exit != 1)
            {

                Console.WriteLine();

                Console.WriteLine("Start \nExit");
                Console.WriteLine();
                Console.Write("Command: ");

                string choose = Console.ReadLine();

                Console.WriteLine();

                if (choose == "Start" || choose == "start")
                {

                    Console.Write("Enter First Number: ");
                    int fnum = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Second Number: ");
                    int snum = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Third Number: ");
                    int tnum = Convert.ToInt32(Console.ReadLine());

                    if (fnum > snum && fnum > tnum)
                    {

                        Console.WriteLine(fnum + " is greater than " + snum + " & " + tnum);

                    }
                    else if (snum > fnum && snum > tnum)
                    {

                        Console.WriteLine(snum + " is greater than " + fnum + " & " + tnum);

                    }
                    else if (tnum > fnum && tnum > snum)
                    {

                        Console.WriteLine(tnum + " is greater than " + fnum + " & " + snum); ;
                    }

                }
                else if (choose == "Exit" || choose == "exit")
                {
                    exit++;

                }

            }


        }
    }
}

