﻿using System;

namespace Acosta_JoenielRuben_M
{
    public class ComputingSumUsingDouble
    {
        public static void Main(string[] args)
        {


            Console.Write("Enter First Number: ");
            double fnum = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            double snum = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("Total: " + (fnum + snum));


        }
    }
}

