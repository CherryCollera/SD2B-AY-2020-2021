﻿using System;

namespace Acosta_JoenielRuben_M
{
    public class ComputeTheSumUsingInt
    {
        public static void Main(string[] args)
        {

            Console.Write("Enter First Number: ");
            int fnum = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            int snum = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("Total: {0}", fnum + snum);

        }
    }
}

