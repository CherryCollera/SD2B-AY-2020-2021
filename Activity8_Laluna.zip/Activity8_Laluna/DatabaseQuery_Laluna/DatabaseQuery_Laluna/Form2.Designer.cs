﻿namespace DatabaseQuery_Laluna
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listBoxGroupbyGPA = new System.Windows.Forms.ListBox();
            this.btn_GroupbyGPA = new System.Windows.Forms.Button();
            this.labelAverage = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelCount = new System.Windows.Forms.Label();
            this.btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.listBoxMinGPA = new System.Windows.Forms.ListBox();
            this.textBox_MinGPA = new System.Windows.Forms.TextBox();
            this.btnShowRecords = new System.Windows.Forms.Button();
            this.labelMinGPA = new System.Windows.Forms.Label();
            this.listBoxHighGPA = new System.Windows.Forms.ListBox();
            this.btnHighGPA = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cartmanCollegeDataSet1 = new DatabaseQuery_Laluna.CartmanCollegeDataSet1();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblStudentsTableAdapter = new DatabaseQuery_Laluna.CartmanCollegeDataSet1TableAdapters.tblStudentsTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // listBoxGroupbyGPA
            // 
            this.listBoxGroupbyGPA.FormattingEnabled = true;
            this.listBoxGroupbyGPA.Location = new System.Drawing.Point(746, 67);
            this.listBoxGroupbyGPA.Name = "listBoxGroupbyGPA";
            this.listBoxGroupbyGPA.Size = new System.Drawing.Size(202, 225);
            this.listBoxGroupbyGPA.TabIndex = 59;
            // 
            // btn_GroupbyGPA
            // 
            this.btn_GroupbyGPA.Location = new System.Drawing.Point(744, 15);
            this.btn_GroupbyGPA.Name = "btn_GroupbyGPA";
            this.btn_GroupbyGPA.Size = new System.Drawing.Size(204, 31);
            this.btn_GroupbyGPA.TabIndex = 58;
            this.btn_GroupbyGPA.Text = "Group Records by GPA";
            this.btn_GroupbyGPA.UseVisualStyleBackColor = true;
            this.btn_GroupbyGPA.Click += new System.EventHandler(this.btn_GroupbyGPA_Click);
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(532, 188);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(35, 13);
            this.labelAverage.TabIndex = 57;
            this.labelAverage.Text = "label4";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(532, 147);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(35, 13);
            this.labelMax.TabIndex = 56;
            this.labelMax.Text = "label3";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(532, 105);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(35, 13);
            this.labelMin.TabIndex = 55;
            this.labelMin.Text = "label2";
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(532, 67);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(35, 13);
            this.labelCount.TabIndex = 54;
            this.labelCount.Text = "label1";
            // 
            // btn_ViewGradeStat
            // 
            this.btn_ViewGradeStat.Location = new System.Drawing.Point(516, 15);
            this.btn_ViewGradeStat.Name = "btn_ViewGradeStat";
            this.btn_ViewGradeStat.Size = new System.Drawing.Size(204, 31);
            this.btn_ViewGradeStat.TabIndex = 53;
            this.btn_ViewGradeStat.Text = "View Grade Statistics";
            this.btn_ViewGradeStat.UseVisualStyleBackColor = true;
            this.btn_ViewGradeStat.Click += new System.EventHandler(this.btn_ViewGradeStat_Click);
            // 
            // listBoxMinGPA
            // 
            this.listBoxMinGPA.FormattingEnabled = true;
            this.listBoxMinGPA.Location = new System.Drawing.Point(276, 287);
            this.listBoxMinGPA.Name = "listBoxMinGPA";
            this.listBoxMinGPA.Size = new System.Drawing.Size(205, 95);
            this.listBoxMinGPA.TabIndex = 52;
            // 
            // textBox_MinGPA
            // 
            this.textBox_MinGPA.Location = new System.Drawing.Point(381, 223);
            this.textBox_MinGPA.Name = "textBox_MinGPA";
            this.textBox_MinGPA.Size = new System.Drawing.Size(99, 20);
            this.textBox_MinGPA.TabIndex = 51;
            // 
            // btnShowRecords
            // 
            this.btnShowRecords.Location = new System.Drawing.Point(275, 254);
            this.btnShowRecords.Name = "btnShowRecords";
            this.btnShowRecords.Size = new System.Drawing.Size(100, 27);
            this.btnShowRecords.TabIndex = 50;
            this.btnShowRecords.Text = " Show Records";
            this.btnShowRecords.UseVisualStyleBackColor = true;
            this.btnShowRecords.Click += new System.EventHandler(this.btnShowRecords_Click);
            // 
            // labelMinGPA
            // 
            this.labelMinGPA.AutoSize = true;
            this.labelMinGPA.Location = new System.Drawing.Point(272, 230);
            this.labelMinGPA.Name = "labelMinGPA";
            this.labelMinGPA.Size = new System.Drawing.Size(103, 13);
            this.labelMinGPA.TabIndex = 49;
            this.labelMinGPA.Text = "Enter minimum GPA:";
            // 
            // listBoxHighGPA
            // 
            this.listBoxHighGPA.FormattingEnabled = true;
            this.listBoxHighGPA.Location = new System.Drawing.Point(37, 278);
            this.listBoxHighGPA.Name = "listBoxHighGPA";
            this.listBoxHighGPA.Size = new System.Drawing.Size(204, 108);
            this.listBoxHighGPA.TabIndex = 48;
            // 
            // btnHighGPA
            // 
            this.btnHighGPA.Location = new System.Drawing.Point(37, 221);
            this.btnHighGPA.Name = "btnHighGPA";
            this.btnHighGPA.Size = new System.Drawing.Size(204, 31);
            this.btnHighGPA.TabIndex = 47;
            this.btnHighGPA.Text = " Show Students with High GPA";
            this.btnHighGPA.UseVisualStyleBackColor = true;
            this.btnHighGPA.Click += new System.EventHandler(this.btnHighGPA_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(37, 15);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(444, 186);
            this.dataGridView1.TabIndex = 46;
            // 
            // cartmanCollegeDataSet1
            // 
            this.cartmanCollegeDataSet1.DataSetName = "CartmanCollegeDataSet1";
            this.cartmanCollegeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet1;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 400);
            this.Controls.Add(this.listBoxGroupbyGPA);
            this.Controls.Add(this.btn_GroupbyGPA);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.btn_ViewGradeStat);
            this.Controls.Add(this.listBoxMinGPA);
            this.Controls.Add(this.textBox_MinGPA);
            this.Controls.Add(this.btnShowRecords);
            this.Controls.Add(this.labelMinGPA);
            this.Controls.Add(this.listBoxHighGPA);
            this.Controls.Add(this.btnHighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form2";
            this.Text = "Database Query Laluna";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox listBoxGroupbyGPA;
        private System.Windows.Forms.Button btn_GroupbyGPA;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Button btn_ViewGradeStat;
        private System.Windows.Forms.ListBox listBoxMinGPA;
        private System.Windows.Forms.TextBox textBox_MinGPA;
        private System.Windows.Forms.Button btnShowRecords;
        private System.Windows.Forms.Label labelMinGPA;
        private System.Windows.Forms.ListBox listBoxHighGPA;
        private System.Windows.Forms.Button btnHighGPA;
        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet1 cartmanCollegeDataSet1;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSet1TableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
    }
}