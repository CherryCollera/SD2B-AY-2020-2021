﻿

namespace WindowsFormsApp1_Laluna
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Birthday " + firstname;
        }
    }
}
