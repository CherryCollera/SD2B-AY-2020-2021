﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1_Laluna
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_getmessage_Click(object sender, EventArgs e)
        {
            HappyBirthday hb = new HappyBirthday();
            MessageBox.Show(hb.GetMessage("Justine!"));
            this.Close();
        }
    }
}
