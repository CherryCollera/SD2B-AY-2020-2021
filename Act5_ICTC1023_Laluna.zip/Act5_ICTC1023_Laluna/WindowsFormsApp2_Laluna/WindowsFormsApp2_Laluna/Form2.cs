﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Laluna
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_getmessage_Click(object sender, EventArgs e)
        {
            String j, l;

            j = txtfn.Text;
            l = txtln.Text;

            MessageBox.Show("Happy Birthday " + j + " " + l);
        }

        private void btn_Hide_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }
    }
}
