﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Laluna
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_getmyprofile_Click(object sender, EventArgs e)
        {
            String j, l;

            j = txtfn.Text;
            l = txtln.Text;

            MessageBox.Show("\t\tHello " + j + " " + l + "\nDate of Birth\t: \tNovember 13, 2000" + "\nCourse\t\t: \tBS COMPUTER SCIENCE" + "\nYear\t\t: \t2" + "\nSection\t\t: \tB");
        }

        private void btn_Hide_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }
    }
}
