﻿using System;

namespace CompareNumbers
{
    class CompareNumbers
    {
        static void Main(string[] args)
        {
            Console.Write("Enter 1st Number: ");
            int A = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd Number: ");
            int B = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 3rd Number: ");
            int C = Convert.ToInt32(Console.ReadLine());

            if (A > B && A > C)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", A,B,C);
                Console.WriteLine("{0} is less than {1}", B,A);
                Console.WriteLine("{0} is less than {1}", C,A);
            }
            else if (B > A && B > C)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", B,A,C);
                Console.WriteLine("{0} is less than {1}", A,B);
                Console.WriteLine("{0} is less than {1}", C,B);
            }
            else if (C > A && C > B)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", C,A,B);
                Console.WriteLine("{0} is less than {1}", A,C);
                Console.WriteLine("{0} is less than {1}", B,C);
            }
            else if (A == B && A > C)
            {
                Console.WriteLine("{0} and {1} is greater than {2}", A,B,C);
                Console.WriteLine("{0} is less than {1}", C,A);
                Console.WriteLine("{0} is less than {1}", C,B);
            }
            else if (A > B && A == C)
            {
                Console.WriteLine("{0} and {1} is greater than {2}", A,C,B);
                Console.WriteLine("{0} is less than {1}", B,A);
                Console.WriteLine("{0} is less than {1}", B,C);
            }
            else if (B == C && B > A)
            {
                Console.WriteLine("{0} and {1} is greater than {2}", B,C,A);
                Console.WriteLine("{0} is less than {1}", A,B);
                Console.WriteLine("{0} is less than {1}", A,C);
            }
            else if (A == B && A == C)
            {
                Console.WriteLine("{0}, {1} and {2} are equal", A,B,C);
            }
            Console.ReadKey();
        }
    }
}
