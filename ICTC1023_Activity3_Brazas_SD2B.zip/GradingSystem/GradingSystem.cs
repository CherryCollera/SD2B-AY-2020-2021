﻿using System;

namespace GradingSystem
{
    class GradingSystem
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your final grade: ");
            double grade = Convert.ToDouble(Console.ReadLine());
            
            if (grade >= 98 && grade <= 100)
            {
                Console.WriteLine("Grade Equivalent : 1.00");
                Console.WriteLine("Remarks : Excellent");
            } 
            else if (grade >= 95 && grade <= 97)
            {
                Console.WriteLine("Grade Equivalent : 1.25");
                Console.WriteLine("Remarks : Excellent");
            }
            else if (grade >= 92 && grade <= 94)
            {
                Console.WriteLine("Grade Equivalent : 1.50");
                Console.WriteLine("Remarks : Very Good");
            }
            else if (grade >= 89 && grade <= 91)
            {
                Console.WriteLine("Grade Equivalent : 1.75");
                Console.WriteLine("Remarks : Very Good");
            }
            else if (grade >= 86 && grade <= 88)
            {
                Console.WriteLine("Grade Equivalent : 2.00");
                Console.WriteLine("Remarks : Good");
            }
            else if (grade >= 83 && grade <= 85)
            {
                Console.WriteLine("Grade Equivalent : 2.25");
                Console.WriteLine("Remarks : Good");
            }
            else if (grade >= 80 && grade <= 82)
            {
                Console.WriteLine("Grade Equivalent : 2.50");
                Console.WriteLine("Remarks : Fair");
            }
            else if (grade >= 77 && grade <= 79)
            {
                Console.WriteLine("Grade Equivalent : 2.75");
                Console.WriteLine("Remarks : Passed");
            }
            else if (grade >= 75 && grade <= 76)
            {
                Console.WriteLine("Grade Equivalent : 3.00");
                Console.WriteLine("Remarks : Passed");
            }
            else if (grade >= 72 && grade <= 74)
            {
                Console.WriteLine("Grade Equivalent : 4.00");
                Console.WriteLine("Remarks : Conditional");
            }
            else if (grade >= 60 && grade <= 71)
            {
                Console.WriteLine("Grade Equivalent : 5.00");
                Console.WriteLine("Remarks : Failed");
            }
            else
            {
                Console.WriteLine("Grade Equivalent : INC");
                Console.WriteLine("Remarks : INCOMPLETE");
            }
            Console.ReadKey();
        }
    }
}
