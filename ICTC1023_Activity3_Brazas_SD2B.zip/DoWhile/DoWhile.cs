﻿using System;

namespace DoWhile
{
    class DoWhile
    {
        static void Main(string[] args)
        {
            int[] WABBO5_nms = new int[] { 6, 7, 8, 10 };
            int WABB05_sum = 0;
            int i = 0;

            do
            {
                WABB05_sum += WABBO5_nms[i];
                i++;
            } while (i < 4);

            Console.WriteLine(WABB05_sum);
            Console.ReadKey();
        }
    }
}
