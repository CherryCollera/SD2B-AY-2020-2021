using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
 // Compiler version 4.0, .NET Framework 4.5


 namespace OlaytaKhem
 {
   public class Act5_AverageOfGrade
   {
     public static void Main(string[] args)
     {
       double grade1, grade2,grade3,grade4,grade5, result, result2;
       Console.Write("Enter First Grade: ");
       grade1 = Convert.ToDouble(Console.ReadLine());
       Console.Write("Enter Second Grade: ");
       grade2 = Convert.ToDouble(Console.ReadLine());
       Console.Write("Enter Third Grade: ");
       grade3 = Convert.ToDouble(Console.ReadLine());
       Console.Write("Enter Fourth Grade: ");
       grade4 = Convert.ToDouble(Console.ReadLine());
       Console.Write("Enter Fifth Grade: ");
       grade5 = Convert.ToDouble(Console.ReadLine());
       
       result = grade1 + grade2+ grade3 + grade4 + grade5;
       result2 = result / 5;
       
       Console.Write("Total Grade: {0:N3}", result2);
     }
   }
 }
