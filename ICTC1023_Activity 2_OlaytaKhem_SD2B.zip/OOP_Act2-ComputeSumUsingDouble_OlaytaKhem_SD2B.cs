using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
 // Compiler version 4.0, .NET Framework 4.5


 namespace OlaytaKhem
 {
   public class Act2_ComputingSumUsingDouble
   {
     public static void Main(string[] args)
     {
       
       
       Console.Write("Enter First Number: ");
       double first = Convert.ToDouble(Console.ReadLine());
       Console.Write("Enter Second Number: ");
       double second = Convert.ToDouble(Console.ReadLine());
 
       Console.WriteLine();
       
       Console.WriteLine("Total: " + (first + second));
 
 
     }
   }
 }
