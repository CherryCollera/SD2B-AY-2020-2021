using System;

namespace Olayta_Khem_C
{
   public class Sample2_MyProfile
   {
     public static void Main(string[] args)
     {
       
       String name = "Khem Olayta";
       String date_of_birth = "June 15, 2000";
       String course = "BSCS";
       String year_and_section = "SD2B";
       
       Console.WriteLine("Name: " + name + "\n");
       Console.WriteLine("Date of Birth: " + date_of_birth + "\n");
       Console.WriteLine("Course: " + course + "\n");
       Console.WriteLine("Year and Section: " + year_and_section + "\n");
       
       Console.ReadKey();
     }
   }
}