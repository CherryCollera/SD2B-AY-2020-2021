using System;


namespace Olayta_Khem_C
{
   public class Sample1_HelloWorld
   {
     public static void Main(string[] args)
     {
       
       Console.WriteLine("Hello World");
       
       Console.ReadKey();
       
     }
   }
 }
