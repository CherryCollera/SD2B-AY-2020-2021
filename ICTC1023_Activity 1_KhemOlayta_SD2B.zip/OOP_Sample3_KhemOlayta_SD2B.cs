using System;

namespace Olayta_Khem_C{


   public class Sample3_InputMyName
   {
     public static void Main(string[] args)
     {
      
      string yourName;
      Console.Write("What is your name (First name, Last Name): ");
      yourName = Console.ReadLine();
      Console.WriteLine("");
 
      Console.WriteLine("Hello " + yourName);
      Console.WriteLine("Welcome to OOP environment");
       
      Console.ReadKey();
      
     }
   }
 }
