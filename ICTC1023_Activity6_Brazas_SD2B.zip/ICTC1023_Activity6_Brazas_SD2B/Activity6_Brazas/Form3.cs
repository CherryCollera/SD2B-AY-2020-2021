﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Activity6_Brazas
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num = 13;
            MessageBox.Show(num.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float num = 13.78F;
            MessageBox.Show(num.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double num = 13.7889;
            MessageBox.Show(num.ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int num1, num2, sum;
            num1 = Convert.ToInt32(textBox1.Text);
            num2 = Convert.ToInt32(textBox2.Text);
            sum = num1 + num2;
            MessageBox.Show("The sum is" + Convert.ToString(sum));
        }
    }
}
