﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Activity6_Brazas
{
    public partial class Form4 : Form
    {
        double total1 = 0;
        double total2 = 0;
        int count = 0;

        bool plusButtonClicked = false;
        bool minusButtonClicked = false;
        bool multiplyButtonClicked = false;
        bool divideButtonClicked = false;
        public Form4()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textDisplay.Clear();
            total1 = 0;
            total2 = 0;
        }

        private void num1_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num1.Text;
        }

        private void num2_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num2.Text;
        }

        private void num3_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num3.Text;
        }

        private void num4_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num4.Text;
        }

        private void num5_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num5.Text;
        }

        private void num6_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num6.Text;
        }

        private void num7_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num7.Text;
        }

        private void num8_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num8.Text;
        }

        private void num9_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num9.Text;
        }

        private void num0_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + num0.Text;
        }

        private void btndecimal_Click(object sender, EventArgs e)
        {
            textDisplay.Text = textDisplay.Text + btndecimal.Text;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textDisplay.Text);
            textDisplay.Clear();
            plusButtonClicked = true;
            minusButtonClicked = false;
            multiplyButtonClicked = false;
            divideButtonClicked = false;
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textDisplay.Text);
            textDisplay.Clear();
            plusButtonClicked = false;
            minusButtonClicked = true;
            multiplyButtonClicked = false;
            divideButtonClicked = false;
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textDisplay.Text);
            textDisplay.Clear();
            plusButtonClicked = false;
            minusButtonClicked = false;
            multiplyButtonClicked = true;
            divideButtonClicked = false;
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textDisplay.Text);
            textDisplay.Clear();
            plusButtonClicked = false;
            minusButtonClicked = false;
            multiplyButtonClicked = false;
            divideButtonClicked = true;
        }

        private void btnEqual_Click(object sender, EventArgs e)
        {
            if(plusButtonClicked == true)
            {
                total2 = total1 + double.Parse(textDisplay.Text);
            }
            else if (minusButtonClicked == true)
            {
                total2 = total1 - double.Parse(textDisplay.Text);
            }
            else if (multiplyButtonClicked == true)
            {
                total2 = total1 * double.Parse(textDisplay.Text);
            }
            else if(divideButtonClicked == true)
            {
                total2 = total1 / double.Parse(textDisplay.Text);
            }
            textDisplay.Text = total2.ToString();
            total1 = 0;
            total2 = 0;
        }

        private void btnForm1_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            this.Hide();
            F1.Show();
        }

        private void btnForm3_Click(object sender, EventArgs e)
        {
            Form3 F3 = new Form3();
            this.Hide();
            F3.Show();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            count++;
            if (count == 1)
            {
                this.BackColor = Color.YellowGreen;
            }
            else if(count == 2)
            {
                this.BackColor = Color.LightPink;
            }
            else if(count == 3)
            {
                this.BackColor = Color.Teal;
                count = 0;
            }

        }
    }
}
