﻿
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace DeclaringConstant
{

    public static class DeclaringConstant
    {
        public static void MainWindows()
        {
            const double pi = 3.14159;
            double AreaCircle, Radius;
            Console.Write("Enter Radius: ");
            Radius = Convert.ToDouble(Console.ReadLine());
            AreaCircle = pi * Radius * Radius;
            Console.WriteLine("\nRadius: {0:N4}", Radius);
            Console.WriteLine("Area: {0:N4}", AreaCircle);
        }
    }
}