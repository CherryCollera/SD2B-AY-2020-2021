﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace BasicOperations
{

    public static class BasicOperations
    {
        public static void MainWindows()
        {
            double num1, num2;
            Console.Write("1ST Number: ");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("2ND Number: ");
            num2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("\nSum: {0}", num1 + num2);
            Console.WriteLine("Difference: {0}", num1 - num2);
            Console.WriteLine("Product: {0}", num1 * num2);
            Console.WriteLine("Quotient: {0:N4}", num1 / num2);
            Console.WriteLine("Remainder: {0}", num2 % num1);
        }
    }
}