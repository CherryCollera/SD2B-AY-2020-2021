﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace ComputeAverage { 

    public static class ComputeAverage
    {
        public static void MainWindows()
        {
            double AVG, A, B, C, D, E;
            Console.WriteLine("Enter 5 Grades:");
            A = Convert.ToDouble(Console.ReadLine());
            B = Convert.ToDouble(Console.ReadLine());
            C = Convert.ToDouble(Console.ReadLine());
            D = Convert.ToDouble(Console.ReadLine());
            E = Convert.ToDouble(Console.ReadLine());
            AVG = (A + B + C + D + E) / 5;
            Console.Write("\nThe AVERAGE is {0:N3}", AVG);
        }
    }
}
