﻿
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace SumUsingDouble
{

    public static class SumUsingDouble
    {
        public static void MainWindow()
        {
            double num1, num2;
            Console.Write("Enter 1ST Number: ");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter 2ND Number: ");
            num2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("\nThe SUM of the two number is {0}. ", num1 + num2);
            Console.ReadKey();
        }
    }
}

