﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace CompareNumbers
{

    public static class CompareNumbers
    {
        public static void MainWindows()
        {
            do
            {
                Console.Write("Enter 1ST Number: ");
                int A = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter 2ND Number: ");
                int B = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter 3RD Number: ");
                int C = Convert.ToInt32(Console.ReadLine());

                if (A > B && A > C)
                {
                    Console.WriteLine("\n* {0} is GREATER than {1} and {2} *", A, B, C);
                    if (B > C)
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", B, C);
                    }
                    else if (B == C)
                    {
                        Console.WriteLine("* {0} is EQUAL to {1} *", B, C);
                    }
                    else
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", C, B);
                    }
                }
                else if (A < B && A < C)
                {
                    Console.WriteLine("\n* {0} and {1} is GREATER than {2} *", B, C, A);
                    if (B > C)
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", B, C);
                    }
                    else if (B == C)
                    {
                        Console.WriteLine("* {0} is EQUAL to {1} *", B, C);
                    }
                    else
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", C, B);
                    }
                }
                else if (B > A && B > C)
                {
                    Console.WriteLine("\n* {0} is GREATER than {1} and {2} *", B, A, C);
                    if (A > C)
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", A, C);
                    }
                    else if (A == C)
                    {
                        Console.WriteLine("* {0} is EQUAL to {1} *", A, C);
                    }
                    else
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", C, A);
                    }
                }
                else if (B < A && B < C)
                {
                    Console.WriteLine("\n* {0} and {1} is GREATER than {2} *", A, C, B);
                    if (A > C)
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", A, C);
                    }
                    else if (A == C)
                    {
                        Console.WriteLine("* {0} is EQUAL to {1} *", A, C);
                    }
                    else
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", C, A);
                    }
                }
                else if (C > A && C > B)
                {
                    Console.WriteLine("\n* {0} is GREATER than {1} and {2} *", C, A, B);
                    if (A > B)
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", A, B);
                    }
                    else if (A == B)
                    {
                        Console.WriteLine("* {0} is EQUAL to {1} *", A, B);
                    }
                    else
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", B, A);
                    }
                }
                else if (C < A && C < B)
                {
                    Console.WriteLine("\n* {0} and {1} is GREATER than {2} *", A, B, C);
                    if (A > B)
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", A, B);
                    }
                    else if (A == B)
                    {
                        Console.WriteLine("* {0} is EQUAL to {1} *", A, B);
                    }
                    else
                    {
                        Console.WriteLine("* {0} is GREATER than {1} *", B, A);
                    }
                }
                else
                {
                    Console.WriteLine("\n* {0}, {1} and {2} are EQUAL *", A, B, C);
                }

                Console.Write("\npress any key to continue...");
                Console.ReadKey();
                Console.Clear();
            } while (true);
        }
    }
}