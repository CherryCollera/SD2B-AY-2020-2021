﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace SumUsingInt
{

    public static class SumUsingInt
    {
        public static void Main()
        {
            int num1, num2;
            Console.Write("Enter 1ST Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2ND Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nThe SUM of the two number is {0}. ", num1 + num2);
            Console.ReadKey();
        }
    }
}